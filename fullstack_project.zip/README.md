# Fullstack Project
Contains backend, frontend, and database configuration.